import InvoiceBuilder from '@/components/invoice-builder';

export default function InvoiceBuilderPage() {
  return <InvoiceBuilder />;
}
