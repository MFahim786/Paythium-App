'use client';

import PayPortal from './PayPortal';

export default function FileDashboard() {
  return (
    <div className="@container">
      <PayPortal/>
      
     
    </div>
  );
}
